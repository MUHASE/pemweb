<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $mysqli->real_escape_string($_POST['username']);
    $password = $mysqli->real_escape_string($_POST['pass']);
    $email = $mysqli->real_escape_string($_POST['email']);
    $role = $mysqli->real_escape_string($_POST['role']);

    $stmt = $mysqli->prepare("INSERT INTO users (username, password, email, role, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssss", $username, $password, $email, $role);  
    
    if ($stmt->execute()) {
        echo "New record created successfully";
        header("location:login.php");
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $mysqli->close();
}
?>
