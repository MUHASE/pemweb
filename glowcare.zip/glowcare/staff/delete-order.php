<?php
include "../koneksi.php";

$id = $_GET['id'];

$query = "DELETE FROM orders WHERE id='$id'";

if ($mysqli->query($query) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error: " . $query . "<br>" . $mysqli->error;
}
header('Location: index.php');
exit();
?>
