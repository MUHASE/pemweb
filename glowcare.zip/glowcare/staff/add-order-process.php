<?php
include "../koneksi.php";

$user_id = $_POST['user_id'];
$total = $_POST['total'];
$status = $_POST['status'];

$query = $mysqli->prepare("INSERT INTO orders (user_id, total, status, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
$query->bind_param('ids', $user_id, $total, $status); // Ensure types are correct ('i' for integer, 'd' for double, 's' for string)

if ($query->execute()) {
    echo "New record created successfully";
    header('Location: index.php'); // Redirect to a confirmation page or back to the form
    exit();
} else {
    echo "Error: " . $query->error;
}

$query->close();
$mysqli->close();
?>