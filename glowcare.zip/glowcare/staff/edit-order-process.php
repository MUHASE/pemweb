<?php
include "../koneksi.php"; // Make sure your database connection setup is correct

// Collect data from post request
$order_id = $_POST['id'];
$user_id = $_POST['user_id'];
$total = $_POST['total'];
$status = $_POST['status'];

// Prepare update statement
$query = $mysqli->prepare("UPDATE orders SET user_id = ?, total = ?, status = ? WHERE id = ?");
$query->bind_param('idsi', $user_id, $total, $status, $order_id);

if ($query->execute()) {
    echo "Order updated successfully";
    header('Location: index.php'); // Assuming you have a page to list orders
    exit;
} else {
    echo "Error updating record: " . $mysqli->error;
}

$query->close();
$mysqli->close();
?>
