<?php
session_start();
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['pass'];

    $stmt = $mysqli->prepare("SELECT * FROM users WHERE email=? AND password=?");
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        if ($user['password'] === $password) {
            $_SESSION['email'] = $email;
            $_SESSION['role'] = $user['role'];
            $_SESSION['status'] = "login";

            // Redirect based on role
            switch ($user['role']) {
                case 'manajer':
                    header("location:admin/index.php");
                    break;
                case 'staff':
                    header("location:staff/index.php");
                    break;
                default:
                    header("location:login.php"); 
            }
        } else {
            echo "<script>alert('Invalid email or password'); window.location='login.php';</script>";
        }
    } else {
        echo "<script>alert('Invalid email or password'); window.location='login.php';</script>";
    }
    $stmt->close();
}
?>
