<?php
include "../koneksi.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete the product
    $query = $mysqli->prepare("DELETE FROM products WHERE id = ?");
    $query->bind_param('i', $id);

    if ($query->execute()) {
        header('Location: produk.php');
        exit();
    } else {
        echo "Error deleting record: " . $mysqli->error;
    }
} else {
    header('Location: produk.php');
    exit();
}
?>
