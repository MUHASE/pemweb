<?php
include "../koneksi.php";

$nama = $_POST['nama'];
$kategori = $_POST['kategori'];
$desc = $_POST['desc'];
$harga = $_POST['harga'];

$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["img"]["name"]);
move_uploaded_file($_FILES["img"]["tmp_name"], $target_file);

$query = $mysqli->prepare("INSERT INTO products (name, description, category_id, price, image) VALUES (?, ?, ?, ?, ?)");
$query->bind_param('ssids', $nama, $desc, $kategori, $harga, $target_file);

if ($query->execute()) {
    header('Location: produk.php');
    exit();
} else {
    echo "Error: " . $query->error;
}
?>